\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{researchskeleton}[2026/11/20 Research paper template]
\LoadClass[sigconf,screen,nonacm]{acmart}[2022/07/30]

\RequirePackage{booktabs}
\RequirePackage{mathtools}
\RequirePackage{microtype}
\RequirePackage{researchfigures}

% Allow authors to give an institution without a city and country.
\let\@ACM@checkaffil\relax

\setcopyright{cc}
\setcctype[4.0]{by}
\settopmatter{printacmref=false,printfolios=true}
\citestyle{acmauthoryear}
\emergencystretch=1.5em

% HyperXMP otherwise adds ACM publisher and proceedings defaults even in nonacm mode.
\let\hyxmp@parse@acmart\relax
\hypersetup{pdfpublication={Independent Research Paper}}

% HyperXMP uses literal underscores for XML indentation. Pass them as text instead.
\ExplSyntaxOn
\cs_new_protected:Npn \skeleton@setcontactemail #1
  {
    \tl_set:Nx \l_tmpa_tl { \tl_to_str:n {#1} }
    \exp_args:NNx \tl_replace_all:Nnn \l_tmpa_tl
      { \char_generate:nn { 95 } { 12 } } { \textunderscore }
    \hypersetup{pdfcontactemail={\l_tmpa_tl}}
  }
\ExplSyntaxOff

% Keep the first author email as contact metadata without ACM's defaults.
\NewCommandCopy{\skeleton@email}{\email}
\renewcommand{\email}[2][]{%
  \skeleton@email[#1]{#2}%
  \ifx\@pdfcontactemail\@empty
    \IfBlankF{#2}{\skeleton@setcontactemail{#2}}%
  \fi
}

% Keep the PDF creation timestamp, but do not use the build time as dc:date.
\patchcmd{\hyxmp@dc@schema}
  {\hyxmp@singleton@dc[Seq]{date}{\hyxmp@today@xmp}}
  {}{}
  {\ClassWarningNoLine{researchskeleton}{Could not suppress the default XMP date}}

% acmart sets its own creator string when it typesets the title.
\AddToHook{cmd/maketitle/after}{\hypersetup{pdfcreator={LaTeX with researchskeleton}}}

\newcommand{\skeleton@ccurl}{%
  https://creativecommons.org/licenses/\ACM@cc@type/\ACM@cc@version/}
\AtBeginDocument{%
  \ifnum\acm@copyrightmode=15\relax % acmart's Creative Commons mode
    \IfEq{\ACM@cc@type}{zero}{%
      \hypersetup{pdflicenseurl={https://creativecommons.org/publicdomain/zero/1.0/}}%
    }{%
      \hypersetup{pdflicenseurl={\skeleton@ccurl}}%
    }%
  \fi
}

\newcommand{\skeleton@doi}{}
\NewDocumentCommand{\doi}{s m}{%
  \renewcommand{\skeleton@doi}{#2}%
  \IfBooleanTF{#1}{%
    \hypersetup{pdfdoi={}}%
  }{%
    \IfBlankTF{#2}{\hypersetup{pdfdoi={}}}{%
      \hypersetup{pdfdoi={\detokenize{#2}}}}%
  }%
}

\newlength{\skeleton@labelwidth}
\newcommand{\skeleton@badgedim}{50pt}
\newcommand{\skeleton@doigap}{16pt}

\newcommand{\skeleton@doiline}[1]{%
  \IfBlankF{#1}{%
    \settowidth{\skeleton@labelwidth}{\textbf{DOI}\enspace}%
    \par\noindent\hangindent=\skeleton@labelwidth
    \makebox[\skeleton@labelwidth][l]{\textbf{DOI}}%
    \href{https://doi.org/#1}{\nolinkurl{#1}}\par
  }%
}

\newcommand{\skeleton@ccbadge}{%
  \parbox[t]{\skeleton@badgedim}{\vspace{0pt}\centering
    \href{\skeleton@ccurl}{%
      \includegraphics[width=\linewidth]{doclicense-CC-by-88x31}}\par
  }%
}

\newcommand{\skeleton@publicationblock}{%
  \hbox{%
    \skeleton@ccbadge
    \kern\skeleton@doigap
    % Zero initial skip aligns the box tops, not the first baselines.
    \parbox[t]{\dimexpr\linewidth-\skeleton@badgedim-\skeleton@doigap\relax}{%
      \vspace{0pt}\raggedright
      \ExpandArgs{o}\skeleton@doiline{\skeleton@doi}%
      \noindent\href{\skeleton@ccurl}{CC BY~4.0}\par
    }%
  }%
}

% Use acmart's first-page footnote for placement, not the title block.
\NewCommandCopy{\skeleton@licensefootnote}{\footnotetextcopyrightpermission}
\renewcommand{\footnotetextcopyrightpermission}[1]{%
  \skeleton@licensefootnote{%
    \IfEq{\ACM@cc@type/\ACM@cc@version}{by/4.0}{\skeleton@publicationblock}{%
      #1\ExpandArgs{o}\skeleton@doiline{\skeleton@doi}}%
  }%
}
